#-*- coding=utf8 -*-


"""
    all text msg that needed be shown in code or program
"""


Action_Msg_01 = "host arguments error"
Action_Msg_02 = "connect to %s failed, %s"
#-*- coding=utf8 -*-


"""
    all text msg that needed be shown in code or program
"""


Action_Msg_01 = "host arguments error"
Action_Msg_02 = "connect to %s failed, %s"
Action_Msg_03 = u"连接到服务器：【%s】"
Action_Msg_04 = u"机器人就绪. sock [%s]"